package io.hifii.drawertest;
import android.widget.ImageView;

public class CustomImageView extends ImageView {
}
