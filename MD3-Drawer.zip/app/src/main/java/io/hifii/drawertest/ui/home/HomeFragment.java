package io.hifii.drawertest.ui.home;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import io.hifii.drawertest.ObservableScrollView;
import io.hifii.drawertest.R;
import io.hifii.drawertest.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private static final float PHOTO_ASPECT_RATIO = 1.7777777f;
    private static final float DRAWEE_PHOTO_ASPECT_RATIO = 1.33f;
    private int mPhotoHeightPixels;
    private View mAddScheduleButtonContainer;
    private int mAddScheduleButtonContainerHeightPixels;
    private View mScrollViewChild;
    private int mHeaderHeightPixels;
    private View mDetailsContainer;
    private ObservableScrollView mScrollView;
    private View mPhotoViewContainer;
    private boolean mHasPhoto;
    private float mMaxHeaderElevation;
    private View mHeaderBox;
    private Handler mHandler;
    private float mFABElevation;
    private FragmentHomeBinding binding;

    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        return root;

        initViews();
    }

    public void initViews() {
        /* mMaxHeaderElevation = getResources().getDimensionPixelSize(
        R.dimen.session_detail_max_header_elevation); */
        mScrollView = (ObservableScrollView) findViewById(R.id.scroll_view);
        ViewTreeObserver vto = mScrollView.getViewTreeObserver();
        mScrollViewChild.setVisibility(View.VISIBLE);
        mPhotoViewContainer = findViewById(R.id.session_photo_container);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
